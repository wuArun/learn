---
name: rosefinch-monitor-starter
description: 朱雀审计服务客户端集成包，提供操作审计和数据审计功能
dependencies: rosefinch-starter-core, mybatis-spring-boot-starter:3.0.4, jsqlparser:4.9, commons-beanutils:1.11.0
---

# 朱雀审计服务客户端 - Agent Skill 文档

## 使用指南

### 快速集成

#### 1. 添加依赖
```xml
<dependency>
    <groupId>com.catl.rosefinch</groupId>
    <artifactId>rosefinch-monitor-starter</artifactId>
</dependency>
```

### 核心功能使用

#### 1. 操作审计使用
```java
import com.catl.rosefinch.monitor.op.annotation.OperatorAudit;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.multipart.MultipartFile;

@Operation(summary = "上传文件")
@PostMapping("/upload")
@OperatorAudit("上传文件:{#file.name}")
public ResponseEntity<Long> upload(@RequestParam MultipartFile file,
                                   @RequestParam Long appId,
                                   @RequestParam String storageCode) {
    return ResponseEntity.ok(fileService.upload(file, appId, storageCode));
}
```

#### 2. 数据审计自动生效
数据审计功能在配置相应表后自动生效，无需额外代码：
```yaml
rosefinch:
  monitor:
    data:
      enabled: true
      tables:
        - user_table
        - order_table
        - product_table
```

## 配置参数详解

### 操作审计配置
```yaml
rosefinch:
  monitor:
    operation:
      enabled: true  # 是否启用操作审计
      thread-pool:
        core-pool-size: 1        # 核心线程数
        max-pool-size: 10        # 最大线程数
        queue-capacity: 10       # 队列容量
        keep-alive-seconds: 60   # 线程空闲时间(秒)
        allow-core-thread-time-out: false  # 核心线程是否允许超时
        wait-for-tasks-to-complete-on-shutdown: false  # 关闭时是否等待任务完成
        await-termination-seconds: 10      # 关闭等待时间(秒)
```

### 数据审计配置
```yaml
rosefinch:
  monitor:
    data:
      enabled: true      # 是否启用数据审计
      tables:            # 需要审计的数据表列表
        - user_table
        - order_table
        - product_table
      thread-pool:
        core-pool-size: 1        # 核心线程数
        max-pool-size: 10        # 最大线程数
        queue-capacity: 10       # 队列容量
        keep-alive-seconds: 60   # 线程空闲时间(秒)
```

## 核心组件说明

### 1. OperatorAuditAspect
操作审计切面，拦截带有`@OperatorAudit`注解的方法，记录操作日志

### 2. DataChangeInterceptor  
数据变更拦截器，拦截MyBatis的增删改操作，解析SQL并记录数据变更

### 3. MonitorRemoteService
Feign客户端接口，用于将审计数据发送到远程监控服务

## 注意事项

1. **事务支持**: 数据审计支持Spring事务，在事务提交后才会发送审计记录
2. **性能影响**: 审计操作使用异步处理，对主业务流程性能影响极小
3. **错误处理**: 审计数据发送失败不会影响主业务流程，仅记录错误日志
4. **表配置**: 数据审计需要明确配置需要审计的表名，避免不必要的性能开销
5. **SpEL表达式**: 在`@OperatorAudit`注解中可以使用SpEL表达式引用方法参数