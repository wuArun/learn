---
name: rosefinch-generator-starter
description: 朱雀代码生成器，支持多数据库逆向工程和全栈代码生成，提高开发效率
dependencies: spring-boot-starter-web:3.5.6, commons-lang3, commons-io:2.16.1, commons-configuration:1.8, velocity-engine-core:2.4.1
---

# 朱雀代码生成器 - Agent Skill 文档

## 使用指南

### 快速开始

#### 1. 添加依赖
```xml
<dependency>
    <groupId>com.catl.rosefinch</groupId>
    <artifactId>rosefinch-generator-starter</artifactId>
</dependency>
```

#### 2. 配置数据源
```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/your_db
    username: your_username
    password: your_password
```

#### 3. 配置生成器参数
```java
import com.catl.rosefinch.generator.service.GeneratorService;
import com.catl.rosefinch.generator.entity.GeneratorEntity;

@Autowired
private GeneratorService generatorService;

public void generateCode() {
    GeneratorEntity info = new GeneratorEntity();
    info.setTableNames(new String[]{"user_info"});
    info.setPkg("com.yourcompany.project");
    info.setAuthor("developer");
    info.setModulePrefix("your-module");
    info.setTablePrefix("t_");
    
    generatorService.generatorCode(info);
}
```

### 代码生成示例

#### 生成单个表
```java
import com.catl.rosefinch.generator.service.GeneratorService;
import com.catl.rosefinch.generator.entity.GeneratorEntity;

@Autowired
private GeneratorService generatorService;

public void generateCode() {
    GeneratorEntity info = new GeneratorEntity();
    info.setTableNames(new String[]{"user_info"});
    info.setModulePrefix("user");
    info.setAuthor("developer");
    
    generatorService.generatorCode(info);
}
```

#### 批量生成
```java
import com.catl.rosefinch.generator.service.GeneratorService;
import com.catl.rosefinch.generator.entity.GeneratorEntity;

public void batchGenerate() {
    String[] tables = {"user_info", "order_info", "product_info"};
    
    GeneratorEntity info = new GeneratorEntity();
    info.setTableNames(tables);
    info.setModulePrefix("business");
    generatorService.generatorCode(info);
}
```

## 模板定制

### 默认模板结构
代码生成器使用DDD架构模板，生成以下文件：
- `Controller.java.vm` - REST控制器模板
- `E.java.vm` - 实体类模板  
- `Mapper.java.vm` - Mapper接口模板
- `Service.java.vm` - Service接口模板
- `ServiceImpl.java.vm` - Service实现类模板
- `Mapper.xml.vm` - MyBatis映射文件模板

### 自定义模板
模板文件位于：`src/main/resources/template/hzero/ddd/`

## 配置参数详解

### 数据库配置
```yaml
spring:
  datasource:
    driver-class-name: com.mysql.cj.jdbc.Driver
    url: jdbc:mysql://localhost:3306/db_name
    username: root
    password: password
```

### 数据库类型映射配置
支持两种配置方式：
- `generator.properties` - 使用java.util.Date类型
- `rest.properties` - 使用java.time.LocalDate/LocalDateTime类型

### 生成器配置参数
- `pkg` - 基础包名
- `author` - 作者名称
- `tablePrefix` - 表前缀过滤
- 数据库类型与Java类型映射关系

## 最佳实践

### 1. 数据库设计规范
- 使用统一的命名规范
- 添加必要的注释说明
- 设计合理的索引结构

### 2. 代码生成策略
- 先设计数据库再生成代码
- 批量生成相关业务表
- 定期更新模板文件