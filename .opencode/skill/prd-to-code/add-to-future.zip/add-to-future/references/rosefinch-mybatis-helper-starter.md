---
name: rosefinch-mybatis-helper-starter
description: 朱雀Mybatis增强包，提供多语言数据自动处理和数据权限控制功能
dependencies: rosefinch-starter-core, mybatis-spring-boot-starter:3.0.4, jsqlparser:4.9, caffeine:3.1.8
---

# 朱雀Mybatis增强包 - Agent Skill 文档

## 使用指南

### 快速集成

#### 1. 添加依赖
```xml
<dependency>
    <groupId>com.catl.rosefinch</groupId>
    <artifactId>rosefinch-mybatis-helper-starter</artifactId>
</dependency>
```

#### 2. 配置启用功能
```yaml
# 启用多语言和数据权限功能
rosefinch:
  mybatis:
    language:
      enabled: true    # 多语言功能（默认启用）
    data-permission:
      enabled: true    # 数据权限功能
```

### 多语言功能使用

#### 1. 实体类定义
```java
import com.catl.rosefinch.mybatis.annotation.MultiLanguage;
import com.catl.rosefinch.mybatis.annotation.MultiLanguageId;
import com.catl.rosefinch.mybatis.annotation.MultiLanguageField;

@MultiLanguage("user_tl")  // 指定多语言表名
public class User extends BaseEntity {
    
    @MultiLanguageId("user_id")  // 多语言表主键
    private Long id;
    
    @MultiLanguageField("user_name")  // 多语言字段
    private String userName;
    
    @MultiLanguageField("description")
    private String description;
}
```

#### 2. 多语言数据操作
```java
@Service
public class UserService {
    
    @Autowired
    private UserMapper userMapper;
    
    public void createUserWithMultiLanguage() {
        User user = new User();
        user.setId(1L);
        
        // 设置多语言数据
        Map<String, Map<String, String>> tls = new HashMap<>();
        
        Map<String, String> userNameTls = new HashMap<>();
        userNameTls.put("zh-CN", "用户名称");
        userNameTls.put("en-US", "User Name");
        tls.put("userName", userNameTls);
        
        Map<String, String> descTls = new HashMap<>();
        descTls.put("zh-CN", "用户描述");
        descTls.put("en-US", "User Description");
        tls.put("description", descTls);
        
        user.setTls(tls);
        userMapper.insert(user);
    }
}
```

### 数据权限功能使用

#### 1. 权限注解配置
```java
import com.catl.rosefinch.mybatis.datapermission.annotation.DataPermissionIgnore;

@Repository
public interface UserMapper {
    
    // 忽略数据权限校验
    @DataPermissionIgnore
    List<User> selectAllUsers();
    
    // 默认启用数据权限校验
    List<User> selectUsersByCondition(UserQuery query);
}
```

#### 2. 权限工具类
```java
@Service
public class DataPermissionService {
    
    public void executeWithoutPermission() {
        DataPermissionIgnoreUtil.setIgnore();
        try {
            userMapper.selectAllUsers();
        } finally {
            DataPermissionIgnoreUtil.clear();
        }
    }
}
```

## 最佳实践

### 1. 多语言表设计
- 多语言表名遵循`主表名_tl`命名规范
- 包含主表ID字段和语言字段
- 使用统一的字符集和排序规则

### 2. 权限配置管理
- 合理设置权限缓存时间
- 实现权限数据的实时同步
- 处理权限服务的降级策略

### 3. 性能优化
- 合理使用批量操作
- 优化多语言数据的查询性能
- 监控权限拦截的性能影响