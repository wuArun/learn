---
name: rosefinch-excel-starter
description: 朱雀Excel增强开发包，基于EasyExcel封装，提供强大的Excel导入导出功能和数据处理能力
dependencies: rosefinch-starter-core, easyexcel:4.0.3
---

# 朱雀Excel增强开发包 - Agent Skill 文档

## 使用指南

### 快速集成

#### 1. 添加依赖
```xml
<dependency>
    <groupId>com.catl.rosefinch</groupId>
    <artifactId>rosefinch-excel-starter</artifactId>
</dependency>
```

#### 2. 自动配置
模块自动配置，无需额外配置项。通过`ExcelReaderConfiguration`自动注册组件。

### 核心功能使用

#### 1. 注解方式导出（推荐）
```java
import com.catl.rosefinch.excel.write.aop.ExcelExport;

@RestController
public class UserController {
    
    @GetMapping("/users")
    @ExcelExport(exportClass = User.class, fileName = "用户列表")
    public List<User> getUsers() {
        return userService.getAllUsers();
    }
}
```

导出时需要在请求头中添加：
- `IS_EXPORT: true` 或 `IS-EXPORT: true`
- `FILE_NAME: 自定义文件名`（可选）

#### 2. 编程方式导出
```java
import com.catl.rosefinch.excel.config.ExcelFactory;
import javax.servlet.http.HttpServletResponse;

@Service
public class ExportService {
    
    public void exportUserList(HttpServletResponse response) {
        List<User> userList = userService.getAllUsers();
        
        ExcelFactory.getWriterBuilder()
            .setDefaultDateConverter()
            .addSheetHandler(User.class, userList)
            .doWrite(response, "用户列表");
    }
}
```

#### 3. 数据导入
```java
import com.catl.rosefinch.excel.config.ExcelFactory;
import com.catl.rosefinch.excel.read.ISheetHandler;
import com.catl.rosefinch.excel.exception.ExcelBusinessException;

@Service
public class ImportService {
    
    public List<ReadResult> importUsers(InputStream inputStream) {
        return ExcelFactory.getReadBuilder()
            .file(inputStream)
            .setDefaultDateConverter()
            .addSheetHandler(new UserImportHandler())
            .doRead();
    }
    
    private class UserImportHandler implements ISheetHandler<User> {
        @Override
        public void doSheetHandler(List<User> validSuccessList, Map<String, Object> argsMap) {
            // 批量处理导入的用户数据
            userService.batchSave(validSuccessList);
        }
    }
}
```

#### 4. 实体类配置
```java
import com.catl.rosefinch.excel.write.aop.ExcelSheetName;
import com.alibaba.excel.annotation.ExcelProperty;

@Data
@ExcelSheetName(sheetName = "用户数据")
public class User {
    
    @ExcelProperty("用户ID")
    private Long id;
    
    @ExcelProperty("用户名")
    @NotBlank(message = "用户名不能为空")
    @Size(max = 50, message = "用户名长度不能超过50")
    private String username;
    
    @ExcelProperty("邮箱")
    @Email(message = "邮箱格式不正确")
    private String email;
    
    @ExcelProperty("创建时间")
    private LocalDateTime createTime;
}
```

## 核心类说明

### ExcelFactory
工厂类，提供构建器获取方法：
- `getReadBuilder()`: 获取读取构建器
- `getWriterBuilder()`: 获取写入构建器

### ReadBuilder
Excel读取构建器，支持：
- 文件输入流配置
- 字符集设置
- 分页大小设置
- Sheet处理器注册
- 时区转换器配置

### WriterBuilder  
Excel写入构建器，支持：
- 输出流配置
- 密码保护
- 内存模式
- 多Sheet导出
- 自定义处理器

### ExcelExportAspect
导出切面，自动拦截带有`@ExcelExport`注解的方法，实现一键导出。

## 最佳实践

### 1. 大文件处理
- 使用分页处理机制，避免内存溢出
- 设置合适的`pageSize`参数
- 实现`ISheetHandler`接口进行批量处理

### 2. 错误处理
- 检查`ReadResult`中的错误记录
- 实现完善的错误信息反馈机制
- 支持错误数据的重新导出

### 3. 国际化支持
- 使用消息代码而非硬编码文本
- 配置多语言表头映射
- 利用`ExcelFactory.getMessageDescription()`进行国际化转换

### 4. 日期时间处理
- 使用`setDefaultDateConverter()`自动处理时区
- 配置用户特定的日期格式
- 确保日期字段的类型一致性