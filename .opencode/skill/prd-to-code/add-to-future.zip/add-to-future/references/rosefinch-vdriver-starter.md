---
name: rosefinch-vdriver-starter
description: 朱雀V盘集成开发包，提供企业级文件管理系统的完整集成方案，支持文件上传、下载、预览等功能
dependencies: rosefinch-starter-core
---

# 朱雀V盘集成开发包 - Agent Skill 文档

## 使用指南

### 快速集成

#### 1. 添加依赖
```xml
<dependency>
    <groupId>com.catl.rosefinch</groupId>
    <artifactId>rosefinch-vdriver-starter</artifactId>
</dependency>
```

#### 2. 配置参数
```yaml
rosefinch:
  vdriver:
    ignore-ssl: true  # 是否忽略SSL认证，默认false
    base-url: https://fileztest.catl.com:5555  # 服务器地址
    app-key: ad2556fca1144fbeb349b99e1e7c0ec5  # 应用密钥
    app-secret: 5e3d4c6619cc4f9da7db7e09a88a4f55  # 应用密钥
```

#### 3. 自动配置
模块通过`VDriverAutoConfiguration`自动配置，自动注册`VDriverClient`和相关服务组件。

### 核心功能使用

#### 1. 基础客户端使用
```java
import com.catl.rosefinch.vdriver.VDriverClient;
import com.catl.rosefinch.vdriver.service.dto.VFileDTO;
import com.catl.rosefinch.vdriver.service.entity.VFile;

@RestController
public class FileController {
    
    @Autowired
    private VDriverClient vDriverClient;
    
    // 获取文件列表
    @GetMapping("/files")
    public VFile getFiles(@RequestParam String path) {
        VFileDTO dto = new VFileDTO();
        dto.setPath(path);
        return vDriverClient.getFiles(dto);
    }
}
```

#### 2. 文件上传
```java
import com.catl.rosefinch.vdriver.VDriverClient;
import com.catl.rosefinch.vdriver.service.entity.UploadFileResponse;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileUploadService {
    
    @Autowired
    private VDriverClient vDriverClient;
    
    // 上传文件（File方式）
    public UploadFileResponse uploadFile(String path, File file) {
        return vDriverClient.uploadFile(path, file);
    }
    
    // 上传文件（MultipartFile方式）
    public UploadFileResponse uploadFile(String path, MultipartFile multipartFile) {
        return vDriverClient.uploadFile(path, multipartFile);
    }
}
```

#### 3. 文件下载
```java
import com.catl.rosefinch.vdriver.VDriverClient;

@Service
public class FileDownloadService {
    
    @Autowired
    private VDriverClient vDriverClient;
    
    // 通过文件ID下载
    public InputStream downloadById(String neid) {
        return vDriverClient.downloadFileById(null, neid, null);
    }
    
    // 通过文件路径下载
    public InputStream downloadByPath(String path) {
        return vDriverClient.downloadFileByPath(null, path, null);
    }
}
```

#### 4. 文件预览
```java
import com.catl.rosefinch.vdriver.VDriverClient;
import com.catl.rosefinch.vdriver.service.dto.VPreviewDTO;
import com.catl.rosefinch.vdriver.service.entity.VPreview;

@Service
public class FilePreviewService {
    
    @Autowired
    private VDriverClient vDriverClient;
    
    // 在线预览文件
    public VPreview previewFile(String neid) {
        VPreviewDTO dto = new VPreviewDTO();
        dto.setNeid(neid);
        dto.setThumbtail(false);
        return vDriverClient.previewFile(dto);
    }
}
```

## 核心类说明

### VDriverClient
主客户端类，提供所有文件管理功能的统一入口：
- `getFiles(VFileDTO dto)` - 获取文件列表
- `getFileInfo(String path)` - 查询文件信息
- `uploadFile()` - 多种方式文件上传
- `downloadFileById()` - 通过ID下载文件
- `downloadFileByPath()` - 通过路径下载文件
- `previewFile(VPreviewDTO dto)` - 文件预览
- `createFolder(String path, String regionId)` - 创建文件夹

### 服务组件
- `TokenService` - OAuth2认证服务，管理访问令牌
- `FileUploadService` - 文件上传服务实现
- `DownloadService` - 文件下载服务实现
- `PreviewFileService` - 文件预览服务实现
- `FolderService` - 文件夹管理服务
- `FileMessageService` - 文件信息查询服务

### 配置类
- `VDriverProperties` - 配置属性类，支持所有星盘API参数配置
- `VDriverAutoConfiguration` - 自动配置类

## 配置说明

### 完整配置参数
```yaml
rosefinch:
  vdriver:
    ignore-ssl: false  # 是否忽略SSL认证
    base-url: https://fileztest.catl.com:5555  # 服务器地址
    app-key: your-app-key  # 应用密钥
    app-secret: your-app-secret  # 应用密钥
    
    # API路径配置（通常使用默认值）
    token-url: /v2/oauth/token
    file-list-url: /v2/api/file
    file-message-url: /v2/api/file/path
    file-message-id-url: /v2/api/file
    file-history-url: /v2/api/file/{neid}/revision
    upload-url: /v2/api/file/content
    download-url: /v2/api/file/content/download
    folder-url: /v2/api/file/folder
    preview-url: /v2/api/preview
    batch-preview-url: /v2/api/preview/batch
```

## 最佳实践

### 1. 认证管理
- 令牌自动管理，无需手动处理认证逻辑
- 支持SSL安全连接，确保数据传输安全
- 配置合适的令牌刷新策略

### 2. 文件操作
- 使用合适的文件路径格式（如：/rosefinch/a/b/c.txt）
- 处理大文件时考虑分块上传机制
- 合理设置分页参数，避免一次性加载过多文件

### 3. 错误处理
- 捕获并处理各种文件操作异常
- 实现重试机制处理网络异常
- 提供友好的错误信息反馈

### 4. 性能优化
- 使用连接池优化HTTP请求性能
- 合理设置超时参数
- 实现文件缓存机制减少重复下载
