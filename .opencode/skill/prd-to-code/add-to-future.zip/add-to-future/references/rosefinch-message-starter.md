---
name: rosefinch-message-starter
description: 朱雀消息服务客户端集成包，提供邮件、COME、短信和站内信等消息发送支持
dependencies: rosefinch-starter-core
---

# 朱雀消息服务客户端 - Agent Skill 文档

## 使用指南

### 快速集成

#### 1. 添加依赖
```xml
<dependency>
    <groupId>com.catl.rosefinch</groupId>
    <artifactId>rosefinch-message-starter</artifactId>
</dependency>
```

#### 2. 自动配置
模块自动配置`MessageClient` Bean，无需额外配置即可使用：

```java
import com.catl.rosefinch.message.MessageClient;

@Autowired
private MessageClient messageClient;
```

## 核心功能使用

### 1. 邮件消息发送
```java
import com.catl.rosefinch.message.MessageClient;
import com.catl.rosefinch.message.entity.Attachment;
import com.catl.rosefinch.message.entity.MessageResult;

@Service
public class EmailService {
    
    @Autowired
    private MessageClient messageClient;
    
    // 发送邮件（需登录，自动获取租户上下文）
    public void sendEmailWithLogin(String serverCode, String templateCode, 
                                  Map<String, String> templateArgMap,
                                  List<String> toEmails, List<String> ccEmails) {
        MessageResult result = messageClient.sendEmailMessage(
            serverCode, templateCode, templateArgMap, toEmails, ccEmails);
        
        if (result.getRes()) {
            // 发送成功
        }
    }
    
    // 发送带附件的邮件
    public void sendEmailWithAttachment(String serverCode, String templateCode,
                                       Map<String, String> templateArgMap,
                                       List<String> toEmails, List<String> ccEmails,
                                       List<Attachment> attachments) {
        MessageResult result = messageClient.sendEmailMessage(
            serverCode, templateCode, templateArgMap, toEmails, ccEmails, attachments);
    }
    
    // 发送邮件（无需登录，指定租户和语言）
    public void sendEmailWithoutLogin(Long tenantId, String lang, String serverCode, 
                                     String templateCode, Map<String, String> templateArgMap,
                                     List<String> toEmails, List<String> ccEmails) {
        MessageResult result = messageClient.sendEmailMessage(
            tenantId, lang, serverCode, templateCode, templateArgMap, toEmails, ccEmails);
    }
}
```

### 2. COME消息发送
```java
import com.catl.rosefinch.message.MessageClient;
import com.catl.rosefinch.message.entity.MessageResult;

@Service
public class ComeMessageService {
    
    @Autowired
    private MessageClient messageClient;
    
    // 发送COME消息（需登录）
    public void sendComeMessage(String serverCode, String templateCode,
                               Map<String, String> templateArgMap,
                               List<String> empCodeList) {
        MessageResult result = messageClient.sendComeMessage(
            serverCode, templateCode, templateArgMap, empCodeList);
    }
    
    // 发送COME消息（无需登录）
    public void sendComeMessageWithoutLogin(Long tenantId, String lang, String serverCode,
                                           String templateCode, Map<String, String> templateArgMap,
                                           List<String> empCodeList) {
        MessageResult result = messageClient.sendComeMessage(
            tenantId, lang, serverCode, templateCode, templateArgMap, empCodeList);
    }
}
```

### 3. 短信消息发送
```java
import com.catl.rosefinch.message.MessageClient;
import com.catl.rosefinch.message.entity.MessageResult;
import com.catl.rosefinch.message.entity.MessageSender;

@Service
public class SmsService {
    
    @Autowired
    private MessageClient messageClient;
    
    // 发送短信（需登录）
    public void sendSms(String serverCode, String smsTemplateId, 
                       List<String> templateArgList, List<MessageSender.User> userList) {
        MessageResult result = messageClient.sendSmsMessage(
            serverCode, smsTemplateId, templateArgList, userList);
    }
    
    // 发送短信（无需登录）
    public void sendSmsWithoutLogin(Long tenantId, String lang, String serverCode,
                                   String smsTemplateId, List<String> templateArgList,
                                   List<MessageSender.User> userList) {
        MessageResult result = messageClient.sendSmsMessage(
            tenantId, lang, serverCode, smsTemplateId, templateArgList, userList);
    }
}
```

### 4. 站内信发送
```java
@Service
public class InternalMessageService {
    
    @Autowired
    private MessageClient messageClient;
    
    // 发送同应用站内信（需登录）
    public void sendInternalMessage(String templateCode, Map<String, String> templateArgMap,
                                   List<String> empCodeList) {
        MessageResult result = messageClient.sendInternalMessage(
            templateCode, templateArgMap, empCodeList);
    }
    
    // 发送内部消息（指定应用和租户）
    public void sendInternalMessageWithApp(Long appId, Long tenantId, String lang,
                                          String templateCode, Map<String, String> templateArgMap,
                                          List<String> empCodeList) {
        MessageResult result = messageClient.sendInternalMessage(
            appId, tenantId, lang, templateCode, templateArgMap, empCodeList);
    }
}
```

## 注意事项

1. **用户上下文**: 需登录的方法自动获取当前用户信息，无需登录的方法需要手动提供租户ID和语言
2. **短信模板**: 短信使用短信云模板ID，而非朱雀消息模板ID
3. **附件支持**: 仅邮件消息支持附件发送
4. **应用上下文**: 所有方法自动获取当前应用ID，支持多应用环境
5. **错误处理**: 消息发送失败会抛出`CommonException`异常