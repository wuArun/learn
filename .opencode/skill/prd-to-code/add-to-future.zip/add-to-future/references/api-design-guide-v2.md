# RESTful API设计规范

## 1. 基础规范

### 1.1 项目结构规范
- `src/main/java/com/company/project/`
  - `common/` # 通用模块
    - `constant/` # 常量类
    - `exception/` # 全局异常
    - `config/` # 配置类
    - `util/` # 工具类
  - `module/` # 业务模块（按模块拆分）
    - `order/` # 订单模块
      - `controller/` # API层
      - `service/` # 业务层
        - `OrderService.java`
        - `impl/`
      - `mapper/` # MyBatis-Plus DAO层
      - `entity/` # 实体类
      - `dto/` # 数据传输对象
        - `request/` # 请求DTO
        - `response/` # 响应DTO
      - `vo/` # 视图对象
    - `workflow/` # Flowable工作流模块
      - `controller/` # 流程相关API
      - `service/` # 流程服务
      - `listener/` # 流程监听器
  - `Application.java` # 启动类
- `src/main/resources/`
  - `mapper/` # MyBatis-Plus XML映射文件
    - `order/`
      - `OrderMapper.xml`
  - `processes/` # Flowable BPMN文件
    - `order_approval.bpmn20.xml`
    - `leave_request.bpmn20.xml`
  - `application.yml` # 主配置文件
  - `application-dev.yml` # 开发环境配置
  - `application-prod.yml` # 生产环境配置

### 1.2 命名规范

#### 1.2.1 包命名
- 全部小写，点分隔：`com.company.project.module.order`

#### 1.2.2 类命名
- **接口/实现类**：`OrderService` / `OrderServiceImpl`
- **Controller**：`OrderController`（REST风格）
- **Mapper**：`OrderMapper`（继承MyBatis-Plus的BaseMapper）
- **实体类**：`Order`（与表名对应，驼峰命名）
- **DTO**：`OrderCreateRequest`、`OrderQueryResponse`
- **VO**：`OrderDetailVO`、`OrderListVO`
- **常量类**：`OrderConstant`、`SecurityConstant`
- **配置类**：`FlowableConfig`、`DataSourceConfig`
- **工具类**：`DateUtil`、`JsonUtil`（私有构造方法，方法static）

#### 1.2.3 方法命名
- **Controller方法**：使用HTTP动词+资源名
  - `getOrderById` (GET)
  - `createOrder` (POST)
  - `updateOrder` (PUT)
  - `deleteOrder` (DELETE)
- **Service方法**：业务动作清晰
  - `submitOrder`、`cancelOrder`、`queryOrderList`
- **Mapper方法**：MyBatis-Plus内置方法可直接使用，自定义用：
  - `selectByUserId`、`updateStatusByOrderId`

#### 1.2.4 字段命名
- **实体类字段**：驼峰，与数据库下划线自动映射
  ```java
  private Long orderId;        // 对应 order_id
  private String userName;      // 对应 user_name
  private LocalDateTime createTime;
  ```
- **常量字段**：大写+下划线
  ```java
  public static final String ORDER_STATUS_PENDING = "PENDING";
  public static final int MAX_ORDER_QUANTITY = 100;
  public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
  ```
- **布尔类型**：使用is前缀（避免使用flag等模糊命名）
  ```java
  private boolean isDeleted;      // 是否删除
  private boolean isActive;       // 是否激活
  private boolean isApproved;     // 是否通过
  ```

### 1.3 API设计原则

#### 1.3.1 RESTful原则
- 使用统一资源标识符（URI）来标识资源
- 使用标准HTTP方法（GET、POST、PUT、DELETE）来操作资源
- 使用HTTP状态码来表示操作结果状态
- 使用无状态通信（Stateless）

#### 1.3.2 一致性原则
- 所有API接口遵循统一的命名风格和结构
- 相同类型的资源使用相同的URI模式
- 错误响应格式保持一致
- 数据格式保持统一（如JSON）

#### 1.3.3 可扩展性原则
- API设计应考虑未来可能的扩展需求
- 使用版本控制机制来管理API变更
- 接口设计应具备向后兼容性

## 2. 详细API设计规范

### 2.1 URI设计规范
- 使用名词而非动词来标识资源
- URI应保持简洁、明确且具有描述性
- 使用小写字母和连字符（-）分隔单词，避免下划线
- 使用复数形式表示资源集合
- 使用层级结构表示资源间的关系

#### 正确示例：
```text
GET /users
GET /users/123
GET /users/123/orders
POST /users
PUT /users/123
DELETE /users/123
```

#### 错误示例：
```text
GET /getUserById?id=123
POST /createUser
PUT /updateUser
DELETE /deleteUser
```

### 2.2 HTTP方法使用规范

#### GET
- 用于获取资源，应该是幂等且安全的
- 通常用于检索数据，而不修改服务器状态

#### POST
- 用于创建新资源
- 可能导致服务器状态改变
- 不应被缓存

#### PUT
- 用于更新现有资源，或是创建新资源
- 应该是幂等的，多次执行结果相同
- 通常用于完整更新资源

#### DELETE
- 用于删除资源
- 应该是幂等的
- 通常用于移除资源

### 2.3 HTTP状态码使用规范

- 200 OK - 请求成功
- 201 Created - 资源创建成功
- 204 No Content - 请求成功但无返回内容
- 400 Bad Request - 请求参数错误
- 401 Unauthorized - 未认证
- 403 Forbidden - 无权限访问
- 404 Not Found - 资源不存在
- 405 Method Not Allowed - 方法不被允许
- 409 Conflict - 资源冲突
- 422 Unprocessable Entity - 请求格式正确但语义错误
- 500 Internal Server Error - 服务器内部错误
- 503 Service Unavailable - 服务不可用

### 2.4 请求参数规范

#### 查询参数（Query Parameters）
- 用于过滤、排序、分页等操作
- 参数名和值应使用URL编码
- 参数应尽量使用标准命名约定

#### 路径参数（Path Parameters）
- 用于标识资源的唯一标识符
- 通常用于GET、PUT、DELETE等操作
- 应该在URI中明确表达

#### 请求体参数（Request Body）
- 用于POST和PUT操作的参数
- 格式通常为JSON，响应也应为JSON
- 所有字段应有明确的文档说明

## 3. 响应规范

### 3.1 统一响应格式
所有API响应都应遵循统一的格式，包括状态码、消息和数据体。

```json
{
  "code": 200,
  "message": "success",
  "data": {}
}
```

### 3.2 错误响应格式
错误响应应该包含明确的错误信息和错误码。

```json
{
  "code": 400,
  "message": "请求参数错误",
  "data": null
}
```

### 3.3 分页响应格式
对于需要分页的接口，响应应包含分页信息。

```json
{
  "code": 200,
  "message": "success",
  "data": {
    "records": [],
    "total": 0,
    "page": 1,
    "size": 10
  }
}
```

## 4. API文档规范

### 4.1 使用Swagger/OpenAPI
- 所有API接口必须提供Swagger文档
- 使用@Operation、@Parameter等注解添加文档信息
- 提供接口参数说明、返回值说明和示例

### 4.2 区分API版本
- 在URI中使用版本号：/api/v1/users
- 支持向后兼容的API版本管理
- 明确标注API版本生命周期

### 4.3 接口描述规范
- 每个接口必须提供清晰的功能描述
- 详细的参数说明和示例
- 返回值说明
- 可能的错误码说明

## 5. 安全规范

### 5.1 认证与授权
- 所有API接口应采用统一认证方式（如JWT）
- 使用适当的授权机制控制访问权限
- 敏感操作应进行额外权限校验

### 5.2 输入验证
- 所有请求参数必须进行合法性校验
- 使用注解进行参数验证（@NotNull, @Size等）
- 防止SQL注入和XSS攻击
- 验证数据类型和格式

### 5.3 数据安全
- 敏感数据在传输过程中使用HTTPS
- 敏感信息加密存储
- 避免在日志中记录敏感信息
- 遵循最小权限原则

### 5.4 API限流
- 对高频调用进行限流控制
- 使用令牌桶或漏桶算法实现限流
- 为不同接口设置不同的限流策略

## 6. 版本控制

### 6.1 版本管理策略
- API版本控制应使用URI路径方式：`/api/v1/`
- 版本号应使用语义化版本控制（SemVer）
- 每个版本应保持向后兼容性

### 6.2 版本更新规范
- 版本更新前应进行充分测试
- 提供版本迁移指南
- 旧版本API应保留一定时间的兼容性
- 向用户明确说明API版本生命周期

### 6.3 版本废弃策略
- 废弃的API版本应提前通知用户
- 提供替代方案
- 设置明确的废弃时间点
- 提供迁移工具或文档

## 7. 性能优化

### 7.1 响应优化
- 合理使用分页避免一次性返回大量数据
- 提供数据压缩功能（Gzip）
- 优化数据库查询，避免N+1问题
- 使用缓存机制减少数据库访问

### 7.2 接口优化
- 合理使用HTTP缓存机制
- 提供条件查询参数，减少无效数据传输
- 优化接口响应时间
- 提供异步接口处理耗时操作

### 7.3 资源管理
- 合理使用连接池管理数据库连接
- 及时释放资源，避免内存泄漏
- 对大文件操作使用流式处理
- 优化图片等静态资源加载

## 8. API设计检查清单

在设计和开发API时，请使用以下检查清单确保质量：

- [ ] URI设计是否符合RESTful风格？
- [ ] HTTP方法使用是否恰当？
- [ ] 状态码返回是否正确？
- [ ] 参数验证是否完整？
- [ ] 错误处理是否合理？
- [ ] 文档是否完整清晰？
- [ ] 是否遵循安全最佳实践？
- [ ] 是否考虑了性能优化？
- [ ] 是否具备良好的可扩展性？
- [ ] 版本控制是否规范？
- [ ] 是否有充分的单元测试？

## 9. 完整示例

### 9.1 用户管理模块示例

#### 9.1.1 创建用户接口
```java
@PostMapping("/users")
@Operation(summary = "创建用户", description = "创建一个新的用户")
public ResponseEntity<ApiResponse<UserResponse>> createUser(
        @Valid @RequestBody CreateUserRequest request) {
    UserResponse user = userService.createUser(request);
    return ApiResponse.success(user);
}
```

#### 9.1.2 查询用户列表接口
```java
@GetMapping("/users")
@Operation(summary = "查询用户列表", description = "分页查询用户列表")
public ResponseEntity<ApiResponse<PageResult<UserResponse>>> getUsers(
        @Parameter(description = "页码") @RequestParam(defaultValue = "1") Integer page,
        @Parameter(description = "每页大小") @RequestParam(defaultValue = "10") Integer size,
        @Parameter(description = "用户名") @RequestParam(required = false) String username) {
    PageResult<UserResponse> result = userService.getUsers(page, size, username);
    return ApiResponse.success(result);
}
```

#### 9.1.3 用户详情接口
```java
@GetMapping("/users/{id}")
@Operation(summary = "获取用户详情", description = "根据用户ID获取用户详细信息")
public ResponseEntity<ApiResponse<UserResponse>> getUserById(
        @Parameter(description = "用户ID") @PathVariable Long id) {
    UserResponse user = userService.getUserById(id);
    return ApiResponse.success(user);
}
```

### 9.2 响应示例

#### 9.2.1 成功响应
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "username": "testuser",
    "email": "test@example.com"
  }
}
```

#### 9.2.2 错误响应
```json
{
  "code": 400,
  "message": "用户名不能为空",
  "data": null
}
```

#### 9.2.3 分页响应
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "records": [
      {
        "id": 1,
        "username": "testuser1",
        "email": "test1@example.com"
      },
      {
        "id": 2,
        "username": "testuser2",
        "email": "test2@example.com"
      }
    ],
    "total": 2,
    "page": 1,
    "size": 10
  }
}
```

## 10. 总结

本API设计规范旨在为Java 17 + Spring Boot项目提供统一的RESTful API设计标准。通过遵循这些规范，可以确保API的：
- 一致性：所有API具有统一的命名、结构和响应格式
- 可维护性：清晰的代码组织和文档结构
- 安全性：合理的认证、授权和数据保护措施
- 可扩展性：便于未来的功能扩展和版本升级
- 易用性：良好的接口设计和文档支持

建议开发团队在项目初期就严格遵守本规范，确保API质量的一致性。