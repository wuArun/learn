---
name: rosefinch-devtool-starter
description: 朱雀本地调试开发工具，支持无平台依赖的本地开发和调试
dependencies: rosefinch-starter-core
---

# 朱雀本地调试开发工具 - Agent Skill 文档

## 使用指南

### 快速集成

#### 1. 添加依赖
```xml
<dependency>
  <groupId>com.catl.rosefinch</groupId>
  <artifactId>rosefinch-devtool-starter</artifactId>
</dependency>
```

#### 2. 配置参数
```yaml
rosefinch:
  admin:
    openapi:
      # 关闭接口是否上报（本地启动请勿开启）
      enabled: false
  oauth:
    #关闭朱雀服务认证（本地启动请勿开启）
    enabled: false
  devtools:
    #打开调试工具
    enabled: true
    mock:
      #朱雀测试环境，用于FeignClient远程请求代理
      platform-url: https://rosefinchapisit.catl.com
      #JWT密钥（可选，默认值：zYHqdG+CJvcieeI+KKPBQCpMYhIS/mdDcrLavb1maI8=）
      jwt-key: zYHqdG+CJvcieeI+KKPBQCpMYhIS/mdDcrLavb1maI8=
      #你的应用id
      app-id: 99
      #你的应用编码
      app-code: xx
      #你的应用名称
      app-name: xx
      #用户语言
      language: zh_CN
      #用户租户
      tenant-id: 0
      #用户时区
      time-zone: +08:00
      #用户id
      user-id: 999
      #用户账号
      login-name: xx
      #邮箱
      email: xx@catl.com
      #JWT令牌（可选，用于Feign请求认证）
      token: xxx
```

#### 3. 请求头覆盖（可选）
支持通过请求头动态覆盖用户配置：
- `mock-appId`: 应用ID
- `mock-language`: 用户语言
- `mock-tenantId`: 租户ID
- `mock-timezone`: 时区
- `mock-userId`: 用户ID
- `mock-loginName`: 登录名
- `mock-email`: 邮箱

## 适用场景

- **无需Nacos等平台服务即可本地运行项目**
- **无需认证即可完成本地接口调试**
- **模拟指定用户进行本地接口调试**
- **代理FeignClient实现本地全链路调试**
- **本地点对点的前后端联调**
- **开发环境与生产环境隔离调试**
