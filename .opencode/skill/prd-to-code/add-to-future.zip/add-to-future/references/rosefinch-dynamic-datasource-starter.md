---
name: rosefinch-dynamic-datasource-starter
description: 朱雀多租户动态数据源开发包，基于baomidou动态数据源框架，提供多租户数据源自动切换和动态管理功能
dependencies: rosefinch-starter-core, dynamic-datasource-spring-boot3-starter:4.3.1
---

# 朱雀多租户动态数据源开发包 - Agent Skill 文档

## 使用指南

### 快速集成

#### 1. 添加依赖
```xml
<dependency>
    <groupId>com.catl.rosefinch</groupId>
    <artifactId>rosefinch-dynamic-datasource-starter</artifactId>
</dependency>
```

#### 2. 自动配置
模块通过`DynamicDataSourceAutoConfig`和`RosefinchDynamicDataSourceAopConfig`自动配置，支持注解驱动和过滤器方式的数据源切换。

### 核心功能使用

#### 1. 注解方式使用（推荐）
```java
import com.catl.rosefinch.datasource.annotation.Master;
import com.catl.rosefinch.datasource.annotation.Slave;
import com.catl.rosefinch.datasource.annotation.TenantDS;

@Service
public class UserService {
    
    @Master
    public User createUser(User user) {
        // 使用主数据源执行操作
        return userMapper.insert(user);
    }
    
    @Slave  
    public User getUserById(Long id) {
        // 使用从数据源执行查询
        return userMapper.selectById(id);
    }
    
    @TenantDS("custom")
    public List<User> getCustomUsers() {
        // 使用指定数据源
        return userMapper.selectList(null);
    }
}
```

#### 2. 自动过滤器方式
启用自动过滤器后，系统会根据当前登录用户的租户信息自动切换数据源：

```java
@RestController
public class UserController {
    
    @GetMapping("/users")
    public List<User> getUsers() {
        // 自动根据当前用户租户切换数据源
        return userService.getAllUsers();
    }
}
```

#### 3. 多数据源事务
```java
import com.catl.rosefinch.datasource.annotation.TenantDSTransactional;

@Service
public class OrderService {
    
    @TenantDSTransactional
    public void createOrder(Order order) {
        // 跨多个数据源的事务操作
        orderMapper.insert(order);
        inventoryMapper.updateStock(order);
    }
}
```

#### 4. 动态数据源管理
```java
import com.baomidou.dynamic.datasource.DynamicRoutingDataSource;
import javax.sql.DataSource;

@Autowired
private DynamicRoutingDataSource routingDataSource;

// 手动添加数据源
public void addDataSource(String dsKey, DataSource dataSource) {
    routingDataSource.addDataSource(dsKey, dataSource);
}

// 手动移除数据源
public void removeDataSource(String dsKey) {
    routingDataSource.removeDataSource(dsKey);
}
```

## 配置说明

### 基础配置
```yaml
rosefinch:
  dynamic:
    datasource:
      enabled: true  # 是否启用租户数据源自动加载、刷新，默认为true
      tenant-ids: [1001, 1002, 1003]  # 配置需要获取租户数据源的租户ID列表
      ds-codes: ["default", "readonly"]  # 多数据源编码列表
      tenant-key: ID  # 数据源标识方式：ID（租户ID）或 CODE（租户代码）
      multi-ds: false  # 是否启用单服务多数据源模式
      
      # 自动过滤器配置
      auto-filter:
        enabled: true  # 是否启用租户数据源自动切换，默认为false
        url-patterns: ["/*"]  # 过滤器匹配的URL模式
        skip-paths: [/tst/**]  # 跳过数据源自动切换的路径
```

### 数据源命名规则
- **单数据源模式**：`tenantId` 或 `tenantCode`（根据tenant-key配置）
- **多数据源模式**：`tenantId_dsCode` 或 `tenantCode_dsCode`

### 数据源配置示例
```yaml
spring:
  datasource:
    dynamic:
      primary: master  # 设置默认数据源
      datasource:
        master:  # 主数据源配置
          driver-class-name: com.mysql.cj.jdbc.Driver
          url: jdbc:mysql://localhost:3306/master_db
          username: root
          password: 123456
        slave:  # 从数据源配置
          driver-class-name: com.mysql.cj.jdbc.Driver
          url: jdbc:mysql://localhost:3306/slave_db
          username: root
          password: 123456
```

## 核心类说明

### 主要组件
- `DynamicDataSourceHandler` - 动态数据源处理器，负责数据源的加载和刷新
- `DynamicDataSourceFilter` - 自动数据源切换过滤器
- `RosefinchDynamicDataSourceAnnotationInterceptor` - 注解拦截器
- `DynamicDataSourceProperties` - 配置属性类
- `RosefinchDataSourceClassResolver` - 数据源注解解析器

### 注解类
- `@TenantDS` - 数据源选择注解
- `@Master` - 主数据源注解（等同于@TenantDS("master")）
- `@Slave` - 从数据源注解（等同于@TenantDS("slave")）
- `@TenantDSTransactional` - 多数据源事务注解

## 最佳实践

### 1. 多租户数据源规划
- 合理规划数据源划分策略
- 根据业务需求配置多数据源模式
- 确保数据源命名规范统一

### 2. 性能优化
- 合理配置连接池参数
- 监控数据源连接状态和性能
- 根据并发量优化数据源配置

### 3. 安全控制
- 严格管理数据源访问权限
- 确保Admin服务连接安全
- 实现完善的数据备份机制
