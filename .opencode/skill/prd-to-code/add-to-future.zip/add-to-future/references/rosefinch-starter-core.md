---
name: rosefinch-starter-core
description: 朱雀微服务平台核心基础包，提供统一的异常处理、JWT安全认证、服务治理等基础能力
dependencies: Jdk17, spring-boot-starter-parent:3.5.6, spring-cloud-dependencies:2025.0.0, hutool-core:5.8.25, spring-cloud-alibaba-dependencies:2025.0.0.0
---

# 朱雀核心基础包 - Agent Skill 文档

## 使用指南

### 快速集成

```java
import com.catl.rosefinch.core.annoation.EnableRosefinch;

// 1. 添加启动注解
@SpringBootApplication
@EnableRosefinch
public class DemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }
}
```

### 核心功能调用

#### 异常处理
```java
import com.catl.rosefinch.core.exception.CommonException;

// 统一异常处理，自动捕获并返回标准格式
throw new CommonException("error.code", "参数");
```

#### 用户信息获取
```java
import com.catl.rosefinch.core.oauth.CustomUserDetails;
import com.catl.rosefinch.core.oauth.SecurityContextHelper;

// 获取当前登录用户信息
CustomUserDetails user = SecurityContextHelper.getUserDetails();
Long tenantId = user.getTenantId();
String language = user.getLanguage();

// 获取用户信息或匿名用户
CustomUserDetails userOrAnonymous = SecurityContextHelper.getUserDetailsElseAnonymous();
```

#### 序列号生成
```java
import com.catl.rosefinch.core.coderule.CodeRuleClient;

@Autowired
private CodeRuleClient codeRuleClient;

public String generateOrderCode() {
    return codeRuleClient.getSequence("ORDER_CODE");
}

// 指定租户和应用生成序列号
public String generateCodeForTenant(String code, Long tenantId, Long appId) {
    return codeRuleClient.getSequence(code, tenantId, appId);
}
```

#### 值集(LOV)查询
```java
import com.catl.rosefinch.core.lov.LovAdapter;
import com.catl.rosefinch.core.lov.entity.ValueSet;

@Autowired
private LovAdapter lovAdapter;

// 已登录场景下查询值集
List<ValueSet> statusValues = lovAdapter.getValues("ORDER_STATUS");

// 未登录场景下查询值集（需要指定租户和语言）
List<ValueSet> typeValues = lovAdapter.getValues("USER_TYPE", 1L, "zh_CN");
```

#### 消息国际化
```java
import com.catl.rosefinch.core.message.MessageAccessor;
import com.catl.rosefinch.core.message.entity.Message;

@Autowired
private MessageAccessor messageAccessor;

// 获取国际化消息描述
String message = messageAccessor.getDescription("zh_CN", "error.user.not_found", null);

// 带参数的国际化消息
String formattedMessage = messageAccessor.getDescription("en_US", "welcome.message",  "张三");

// 获取完整的消息对象
Message msg = messageAccessor.getMessage("zh_CN", "error.code", null);
```

#### 页面提示语获取
```java
import com.catl.rosefinch.core.prompt.PromptAccessor;

@Autowired
private PromptAccessor promptAccessor;

// 获取提示词描述
String prompt = promptAccessor.getDescription(appId, "zh_CN", "promptKey", "promptCode");
```

#### XSS防护
```java
import com.catl.rosefinch.core.xss.XssEscape;

// 在Controller方法上添加XSS防护注解
@XssEscape(fields = {"content", "title"}, type = XssEscape.ALL)
public void saveArticle(@RequestBody Article article) {
    // 方法执行前会自动对content和title字段进行XSS过滤
    articleService.save(article);
}

// 脚本标签过滤防护
@XssEscape(fields = {"description"}, type = XssEscape.SCRIPT)
public void updateProduct(@RequestBody Product product) {
    // description字段会自动过滤script标签
}

// 支持SpEL表达式指定嵌套字段
@XssEscape(fields = {"user.name", "user.email", "items[%d].content"}, type = XssEscape.ALL)
public void submitForm(@RequestBody FormData form) {
    // 支持嵌套对象和列表字段的XSS防护
}
```

#### 值集翻译注解
```java
import com.catl.rosefinch.core.lov.ProcessLovValue;

// 在Controller方法上添加值集翻译注解
@ProcessLovValue(targetField = {"status", "type"})
@GetMapping("/orders")
public List<Order> getOrders() {
    // 返回结果中的status和type字段会自动进行值集翻译
    return orderService.findAll();
}
```

#### 健康检查端点
```bash
# 检查服务健康状态
curl -X GET http://localhost:8080/login-api/heartbeat
```

## 配置参数详解

### 必需配置
```yaml
rosefinch:
  app-code: "your-app-code"  # 应用唯一标识
```

### 可选配置
```yaml
rosefinch:
  admin:
    openapi:
      enabled: true  # 是否启用API文档上报，默认true
  oauth:
    enabled: true    # 是否启用JWT认证，默认true
    skip-paths:      # 跳过认证的路径
      - "/public/**"
  jackson:
    enabled: true    # 是否启用自定义Jackson配置
    date-formatter: "yyyy-MM-dd'T'HH:mm:ss.SSSZ"  # 日期格式化
    need-throw-exception: true  # 是否抛出异常
  pagesize:
    enabled: false   # 是否启用分页大小限制
    max: 200         # 最大分页大小
```

### 服务发现配置
```yaml
spring:
  cloud:
    nacos:
      discovery:
        server-addr: localhost:8848  # Nacos服务地址
        group: DEFAULT_GROUP         # 服务分组
  application:
    name: your-service-name          # 服务名称
```

### Feign客户端配置
```yaml
feign:
  client:
    config:
      default:
        connect-timeout: 5000    # 连接超时时间
        read-timeout: 5000       # 读取超时时间
  circuitbreaker:
    enabled: true                # 启用断路器
```

## XSS防护配置说明

### 防护类型说明
- **`XssEscape.ALL`**: 全量HTML转义，对所有HTML特殊字符进行转义
- **`XssEscape.SCRIPT`**: 仅过滤脚本标签，替换`<script>`和`</script>`标签

### 使用示例
```java
import com.catl.rosefinch.core.xss.XssEscape;

// 全量HTML转义防护
@XssEscape(fields = {"content", "title"}, type = XssEscape.ALL)
public void saveArticle(@RequestBody Article article) {
    // content和title字段会自动进行HTML转义
}

// 脚本标签过滤防护
@XssEscape(fields = {"description"}, type = XssEscape.SCRIPT)
public void updateProduct(@RequestBody Product product) {
    // description字段会自动过滤script标签
}

// 支持SpEL表达式指定嵌套字段
@XssEscape(fields = {"user.name", "user.email", "items[%d].content"}, type = XssEscape.ALL)
public void submitForm(@RequestBody FormData form) {
    // 支持嵌套对象和列表字段的XSS防护
}
```