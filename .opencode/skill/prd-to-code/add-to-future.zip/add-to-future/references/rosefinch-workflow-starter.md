---
name: rosefinch-workflow-starter
description: 朱雀BPM工作流集成开发包，提供企业级工作流引擎的完整集成方案，支持流程创建、审批、查询等全生命周期管理
dependencies: rosefinch-starter-core
---

# 朱雀BPM工作流集成开发包 - Agent Skill 文档

## 使用指南

### 快速集成

#### 1. 添加依赖
```xml
<dependency>
    <groupId>com.catl.rosefinch</groupId>
    <artifactId>rosefinch-workflow-starter</artifactId>
</dependency>
```

#### 2. 配置参数
```yaml
rosefinch:
  workflow:
    ipaas-url: http://your-ipaas-server.com  # iPaas服务地址
    connect-timeout: 5000  # 连接超时时间(ms)
    read-timeout: 30000    # 读取超时时间(ms)
    request-log-enabled: true  # 请求日志开关
    response-log-enabled: true  # 响应日志开关
    jwt-enabled: false     # JWT认证开关
    client-key: your-client-key  # 客户端密钥
    client-secret: your-client-secret  # 客户端密钥
```

#### 3. 自动配置
模块通过`WorkflowClientConfiguration`自动配置，自动注册`WorkflowClient`和`RestTemplate`。

### 核心功能使用

#### 1. 基础客户端使用
```java
import com.catl.rosefinch.workflow.WorkflowClient;
import com.catl.rosefinch.workflow.entity.request.CreateFlow;
import com.catl.rosefinch.core.oauth.SecurityContextHelper;

@RestController
public class WorkflowController {
    
    @Autowired
    private WorkflowClient workflowClient;
    
    // 创建流程实例
    @PostMapping("/workflow/create")
    public String createWorkflow(@RequestBody CreateFlowRequest request) {
        CreateFlow createFlow = new CreateFlow();
        createFlow.setWorkflowId(request.getWorkflowId());
        createFlow.setRequestname(request.getTitle());
        createFlow.setWorkcode(SecurityContextHelper.getCurrentWorkcode());
        return workflowClient.createFlow(createFlow);
    }
}
```

#### 2. 流程审批操作
```java
import com.catl.rosefinch.workflow.WorkflowClient;
import com.catl.rosefinch.workflow.entity.request.AgreeFlow;
import com.catl.rosefinch.workflow.entity.request.RejectFlow;
import com.catl.rosefinch.core.oauth.SecurityContextHelper;

@Service
public class WorkflowService {
    
    @Autowired
    private WorkflowClient workflowClient;
    
    // 同意流程
    public String approveFlow(String requestId, Map<String, Object> formData) {
        AgreeFlow agreeFlow = new AgreeFlow();
        agreeFlow.setRequestId(requestId);
        agreeFlow.setWorkcode(SecurityContextHelper.getCurrentWorkcode());
        agreeFlow.setFormdata(formData);
        return workflowClient.agreeFlow(agreeFlow);
    }
    
    // 退回流程
    public String rejectFlow(String requestId, String remark) {
        RejectFlow rejectFlow = new RejectFlow();
        rejectFlow.setRequestId(requestId);
        rejectFlow.setWorkcode(SecurityContextHelper.getCurrentWorkcode());
        rejectFlow.setRemark(remark);
        return workflowClient.rejectFlow(rejectFlow);
    }
}
```

#### 3. 流程查询操作
```java
import com.catl.rosefinch.workflow.WorkflowClient;
import com.catl.rosefinch.workflow.entity.request.FlowCondition;
import com.catl.rosefinch.workflow.entity.response.vo.DataList;

@Service
public class WorkflowQueryService {
    
    @Autowired
    private WorkflowClient workflowClient;
    
    // 查询我发起的流程
    public List<DataList> getMyWorkflows(String workcode) {
        FlowCondition condition = new FlowCondition();
        condition.setWorkcode(workcode);
        return workflowClient.getMyFlowList(condition);
    }
    
    // 查询待办流程
    public List<DataList> getTodoWorkflows(String workcode) {
        FlowCondition condition = new FlowCondition();
        condition.setWorkcode(workcode);
        return workflowClient.getToDoList(condition);
    }
    
    // 查询流程详情
    public DataInfo getFlowInfo(String requestId, String workcode) {
        FlowInfo flowInfo = new FlowInfo();
        flowInfo.setRequestId(requestId);
        flowInfo.setWorkcode(workcode);
        return workflowClient.getFlowInfo(flowInfo);
    }
}
```

## 核心类说明

### WorkflowClient
主客户端类，提供所有工作流功能的统一入口：
- `createFlow(CreateFlow createFlow)` - 创建流程实例
- `agreeFlow(AgreeFlow agreeFlow)` - 同意流程
- `rejectFlow(RejectFlow rejectFlow)` - 退回流程
- `getMyFlowList(FlowCondition flowCondition)` - 获取我发起的流程列表
- `getToDoList(FlowCondition flowCondition)` - 获取待办流程列表
- `getHandledList(FlowCondition flowCondition)` - 获取已办流程列表
- `getFlowInfo(FlowInfo flowInfo)` - 获取流程信息
- `getFlowStatus(FlowInfo flowInfo)` - 获取流程状态
- `getNextNodeInfo(FlowInfo flowInfo)` - 获取下一节点信息
- `getFlowDetails(FlowInfo flowInfo)` - 获取流程详细信息

### 请求实体类
- `CreateFlow` - 创建流程请求
- `AgreeFlow` - 同意流程请求
- `RejectFlow` - 退回流程请求
- `FlowCondition` - 流程查询条件
- `FlowInfo` - 流程信息查询

### 响应实体类
- `DataList` - 流程列表数据
- `DataInfo` - 流程详细信息
- `DataInfoDetail` - 流程详细数据
- `StatusData` - 流程状态数据

## 配置说明

### 完整配置参数
```yaml
rosefinch:
  workflow:
    # 基础配置
    ipaas-url: http://your-ipaas-server.com  # iPaas服务地址
    deipaaskeyauth: your-auth-key  # 认证密钥
    
    # 超时配置
    connect-timeout: 5000  # 连接超时时间(ms)，默认-1
    read-timeout: 30000    # 读取超时时间(ms)，默认-1
    
    # 日志配置
    request-log-enabled: true  # 请求日志开关
    response-log-enabled: true  # 响应日志开关
    
    # JWT认证配置
    jwt-enabled: false     # JWT认证开关
    client-key: your-client-key  # 客户端密钥
    client-secret: your-client-secret  # 客户端密钥
    validity: 3600         # 令牌有效期(秒)
```

## 最佳实践

### 1. 流程创建
- 合理设置流程标题和密级
- 正确传递表单数据和业务参数
- 处理流程创建失败的情况

### 2. 流程审批
- 确保审批权限验证
- 记录审批意见和操作日志
- 处理审批异常和重试机制

### 3. 流程查询
- 使用分页查询避免数据量过大
- 缓存常用流程数据提高性能
- 实现流程状态监控和告警
