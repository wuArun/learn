---
name: rosefinch-file-starter
description: 朱雀文件服务客户端集成包，提供文件操作和对象存储S3集成能力
dependencies: rosefinch-starter-core, commons-beanutils:1.11.0
---

# 朱雀文件服务客户端 - Agent Skill 文档

## 使用指南

### 快速集成

#### 1. 添加依赖
```xml
<dependency>
    <groupId>com.catl.rosefinch</groupId>
    <artifactId>rosefinch-file-starter</artifactId>
</dependency>
```

#### 2. 自动配置
模块自动配置`FileClient` Bean，无需额外配置即可使用：

```java
import com.catl.rosefinch.file.FileClient;

@Autowired
private FileClient fileClient;
```

## 核心组件

### FileClient 主要方法

#### 文件上传
```java
import org.springframework.web.multipart.MultipartFile;

// 上传文件，默认不公开
Integer fileId = fileClient.upload(multipartFile, "default-storage");

// 上传文件，指定是否公开
Integer fileId = fileClient.upload(multipartFile, "default-storage", true);
```

#### 文件下载
```java
// 获取下载URL（默认不公开）
String downloadUrl = fileClient.getDownloadUrl(fileId);

// 获取下载URL（指定是否公开）
String downloadUrl = fileClient.getDownloadUrl(fileId, true);

// 直接获取文件字节数组
byte[] fileBytes = fileClient.getDownloadByteArray(fileId);
```

#### 文件预览
```java
// 获取文件预览URL
String previewUrl = fileClient.getPreviewUrl("default-storage", fileId);
```

#### S3预签名URL
```java
// 生成S3临时上传URL（相同文件名会被覆盖，建议添加UUID）
String presignedUrl = fileClient.createPresignedUrl("default-storage", "filename.txt");
```

#### 文件信息管理
```java
// 保存文件信息（返回Long类型的文件ID）
Long fileId = fileClient.saveFileInfo("default-storage", "filename.txt", 1024L);

// 删除文件
Integer result = fileClient.remove(fileId);
```

## 注意事项

1. **文件ID类型**: 上传方法返回Integer类型文件ID，保存文件信息方法返回Long类型文件ID
2. **应用上下文**: 所有方法自动使用当前应用ID，无需手动传递
3. **文件名安全**: 建议在文件名中添加UUID避免S3存储中的文件覆盖问题
4. **已弃用方法**: `download(Long fileId)`方法已标记为`@Deprecated`，建议使用`getDownloadByteArray`或`getDownloadUrl`替代