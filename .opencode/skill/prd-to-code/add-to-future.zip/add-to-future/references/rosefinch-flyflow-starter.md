---
name: rosefinch-flyflow-starter
description: 朱雀微服务平台的FlyFlow工作流引擎客户端集成包，提供与FlyFlow工作流引擎的无缝集成，支持流程实例的全生命周期管理。
dependencies: rosefinch-starter-core
---

# flyflow工作流引擎 - Agent Skill 文档

## 快速开始

### 1. 添加依赖

```xml
<dependency>
    <groupId>com.catl.rosefinch</groupId>
    <artifactId>rosefinch-flyflow-starter</artifactId>
</dependency>
```

### 2. 使用FlyflowClient

```java
import com.catl.rosefinch.flyflow.FlyflowClient;
import com.catl.rosefinch.flyflow.request.CompleteTaskRequest;
import com.catl.rosefinch.flyflow.response.vo.ProcessInstanceRecordVO;

@Autowired
private FlyflowClient flyflowClient;

// 创建流程实例
String processInstanceId = flyflowClient.createFlow(
    "approval-flow", 
    "/approval/detail", 
    Map.of("businessId", "123")
);

// 查询待办任务
ProcessInstanceRecordVO todoTask = flyflowClient.queryTodoTask("BIZ001");

// 审批任务
CompleteTaskRequest request = new CompleteTaskRequest();
request.setProcessInstanceId(processInstanceId);
request.setTaskId(taskId);
request.setApproveResult(true);
request.setApproveDesc("同意审批");
flyflowClient.approveFlow(request);
```

## 核心API详解

### FlyflowClient 主要方法

#### 流程实例操作
- `createFlow(String flowUniqueId, String url, Map<String, Object> paramMap)` - 创建流程实例
- `approveFlow(CompleteTaskRequest request)` - 审批流程任务
- `turnFlow(String assignee, String taskId, String processInstanceId)` - 转办任务
- `hurryFlow(String processInstanceId)` - 催办流程
- `delegateTask(TaskAddAssigneeDto dto)` - 委派任务（向前加签）

#### 流程查询操作
- `queryTodoTask(String bizCodeOrInstanceId)` - 查询待办任务
- `queryInitiatedTaskList(ProcessDataQueryDTO queryDTO)` - 查询我的发起
- `queryToDoTaskList(ProcessDataQueryDTO queryDTO)` - 查询我的待办
- `queryFinishedTaskList(ProcessDataQueryDTO queryDTO)` - 查询我的已办
- `queryCopiedTaskList(ProcessDataQueryDTO queryDTO)` - 查询抄送给我

#### 流程显示操作
- `queryTaskOperData(String taskId)` - 查询任务操作数据
- `formatStartNodeShow(NodeFormatParamDto dto)` - 格式化节点显示
- `queryHeaderShow(QueryFormListParamDTO dto)` - 查询流程头部信息

## 配置说明

### 自动配置

模块通过`FlyflowClientConfiguration`自动配置以下Bean：
- `FlyflowRemoteService` - Feign客户端接口
- `FlyflowRemoteServiceFallbackFactory` - 降级工厂
- `FlyflowClient` - 主要业务客户端

### 节点类型支持

模块支持以下流程节点类型（通过`@JsonTypeName`注解标识）：
- `ApproveNode` (1) - 审批节点
- `CopyNode` (2) - 抄送节点
- `EmptyNode` (3) - 空节点
- `ExclusiveGatewayNode` (4) - 排他网关
- `ParallelGatewayNode` (5) - 并行网关
- `DelayNode` (7) - 延迟节点
- `HttpNode` (8) - HTTP调用节点
- `EndNode` (-1) - 结束节点
- `MergeGatewayNode` (-2) - 合并网关

## 使用示例

### 完整的流程操作示例

```java
import com.catl.rosefinch.flyflow.FlyflowClient;

@Service
public class ApprovalService {
    
    @Autowired
    private FlyflowClient flyflowClient;
    
    public String startApprovalProcess(String businessId, String flowUniqueId) {
        // 创建流程实例
        Map<String, Object> params = new HashMap<>();
        params.put("businessId", businessId);
        params.put("applicant", SecurityContextHelper.getCurrentUsername());
        
        return flyflowClient.createFlow(
            flowUniqueId, 
            "/approval/detail/" + businessId, 
            params
        );
    }
    
    public Page<ProcessInstanceRecordVO> getMyTodoTasks(int page, int size) {
        ProcessDataQueryDTO query = new ProcessDataQueryDTO();
        query.setPageNum(page);
        query.setPageSize(size);
        return flyflowClient.queryToDoTaskList(query);
    }
    
    public void approveTask(String processInstanceId, String taskId, boolean approved, String comment) {
        CompleteTaskRequest request = new CompleteTaskRequest();
        request.setProcessInstanceId(processInstanceId);
        request.setTaskId(taskId);
        request.setApproveResult(approved);
        request.setApproveDesc(comment);
        flyflowClient.approveFlow(request);
    }
}
```

## 注意事项

1. **用户上下文**: 所有操作都需要有效的用户上下文信息（appId、tenantId、username）
2. **服务依赖**: 需要确保FlyFlow服务可用且网络连通
3. **异常处理**: 建议在业务代码中捕获`FlyflowException`进行适当处理
4. **性能考虑**: 批量查询时注意分页参数设置，避免大数据量查询

### 日志调试

启用DEBUG日志查看详细调用信息：
```yaml
logging:
  level:
    com.catl.rosefinch.flyflow: DEBUG